package com.indiavpn.fast.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import androidx.core.content.ContextCompat
import com.indiavpn.fast.R

/** Four ascending bars, 0..4 lit. Used for the ping quality of a server. */
class SignalBarsView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var level: Int = 0
        set(value) {
            val v = value.coerceIn(0, BARS)
            if (field == v) return
            field = v
            invalidate()
        }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val density = resources.displayMetrics.density

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(
            resolveSize((22 * density).toInt(), widthMeasureSpec),
            resolveSize((16 * density).toInt(), heightMeasureSpec)
        )
    }

    override fun onDraw(canvas: Canvas) {
        val gap = 2f * density
        val barW = (width - gap * (BARS - 1)) / BARS
        val onColor = ContextCompat.getColor(
            context,
            when {
                level >= 3 -> R.color.statusOnline
                level == 2 -> R.color.statusWarn
                else -> R.color.statusOffline
            }
        )
        val offColor = ContextCompat.getColor(context, R.color.signalOff)
        for (i in 0 until BARS) {
            val h = height * (0.35f + 0.65f * (i / (BARS - 1f)))
            val left = i * (barW + gap)
            rect.set(left, height - h, left + barW, height.toFloat())
            paint.color = if (i < level) onColor else offColor
            canvas.drawRoundRect(rect, barW / 2f, barW / 2f, paint)
        }
    }

    companion object {
        private const val BARS = 4

        /** Bars follow the measured ping: green and full up to 100 ms, orange up to 170 ms, red above.
         *  Not measured yet (-1) or unreachable (-2) shows no lit bars. */
        fun levelForPing(pingMs: Int): Int = when {
            pingMs < 0 -> 0
            pingMs <= 100 -> BARS
            pingMs <= 170 -> 2
            else -> 1
        }

        /** Colour resource for a ping value, shared by the bars and the "xx ms" label. */
        fun colorForPing(pingMs: Int): Int = when {
            pingMs == -2 -> R.color.statusOffline
            pingMs < 0 -> R.color.gray
            pingMs <= 100 -> R.color.statusOnline
            pingMs <= 170 -> R.color.statusWarn
            else -> R.color.statusOffline
        }
    }
}
